import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var check: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        check = findViewById(R.id)


    }
    fun radio1(view: View) {

        Toast.makeText( this, "You have chosen Male", Toast.LENGTH_LONG).show()
    }

    fun radio2(view: View) {

        Toast.makeText( this, "You have chosen Female", Toast.LENGTH_LONG).show()
    }

    fun checkBox(view: View) {

        if (check.isChecked()) {
            Toast.makeText(this, "Agreed", Toast.LENGTH_LONG).show()
        }
    }

}